﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTCG_SWEN1.BL.Models
{
    public class Sessions
    {
        public string Token { get; set; }

        public Guid User { get; set; }

        public DateTime Timestamp { get; set; }        
    }
}
